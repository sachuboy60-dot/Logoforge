# LogoForge

A nostalgic, mobile-friendly logo maker for GitHub Pages.

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/root`, then Save.
6. GitHub will give you the live Pages URL.

## Important
The included AI generator is a browser demo that creates logo concepts locally. A real generative-AI backend requires an API and should keep the API key on a server, not in `index.html`.

The ₹10 VIP buttons are demo checkout buttons. Real payments need a supported payment provider. A normal website cannot directly credit Google Play balance.
